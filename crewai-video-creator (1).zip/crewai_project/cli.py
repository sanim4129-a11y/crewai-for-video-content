import argparse
from crewai_project.crew import build_crewai_video_crew

def main():
    parser = argparse.ArgumentParser(description="CrewAI Video Generator CLI")
    parser.add_argument("--topic", required=True)
    parser.add_argument("--style", default="educational")
    parser.add_argument("--duration", type=int, default=5)
    args = parser.parse_args()

    crew = build_crewai_video_crew()
    result = crew.kickoff(inputs={"topic": args.topic, "style": args.style, "duration": args.duration})
    print("Video generated:", result)

if __name__ == "__main__":
    main()
