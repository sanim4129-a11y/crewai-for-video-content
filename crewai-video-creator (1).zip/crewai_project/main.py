from crewai_project.crew import build_crewai_video_crew

if __name__ == "__main__":
    crew = build_crewai_video_crew()
    result = crew.kickoff(inputs={"topic": "Demo Topic", "style": "educational", "duration": 2})
    print("Video generated:", result)
