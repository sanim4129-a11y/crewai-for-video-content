# 🎥 CrewAI Video Generator

Dynamic AI-powered video generator with CrewAI.  
Supports scripts, TTS, visuals, and video assembly.  
Deployable to Hugging Face Spaces or Google Cloud Run.

## Quickstart
```bash
pip install -r requirements.txt
python crewai_project/cli.py --topic "AI" --style "news" --duration 3
```
